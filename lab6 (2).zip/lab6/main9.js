function writeHello() {
  for (let a = 0; a < 3; a++) {
    if (a == 0) {
      console.log("Hello, World!");
    } else if (a == 1) {
      console.log("Hello, World!");
    } else {
      console.log("Hello, World!");
    }
  }
}


writeHello();

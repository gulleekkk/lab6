function largeNumber(a1, a2) {
  if (a1 > a2) {
    return a1;
  } else {
    return a2;
  }
}

console.log(largeNumber(7, 3)); 
